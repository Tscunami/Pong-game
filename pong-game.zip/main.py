from turtle import Screen
from paddle import Paddle
from ball import Ball
from scoreboard import Scoreboard, Line
import time

screen = Screen()
screen.setup(width=800, height=600)
screen.title("Pong")
screen.bgpic("background.gif")
screen.tracer(0)

r_paddle = Paddle((350, 0))
l_paddle = Paddle((-350, 0))
ball = Ball()
scoreboard = Scoreboard()
line = Line()

screen.listen()
screen.onkeypress(r_paddle.go_up, "Up")
screen.onkeypress(r_paddle.go_down, "Down")
screen.onkeypress(l_paddle.go_up, "w")
screen.onkeypress(l_paddle.go_down, "s")

game_is_on = True
while game_is_on:
    time.sleep(ball.move_speed)
    screen.update()
    ball.move()

    # Detects collision with wall
    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.bounce_wall()

    # Collision with R paddle
    if ball.distance(r_paddle) < 60 and ball.xcor() > 320:
        ball.bounce_paddle()
        r_paddle.ball_hit()

    # Collision with L paddle
    if ball.distance(l_paddle) < 60 and ball.xcor() < -320:
        ball.bounce_paddle()
        l_paddle.ball_hit()

    # If R paddle misses
    if ball.xcor() > 380:
        ball.reset_position()
        scoreboard.l_point()
        time.sleep(1)

    # If L paddle misses:
    if ball.xcor() < -380:
        ball.reset_position()
        scoreboard.r_point()
        time.sleep(1)

screen.exitonclick()
