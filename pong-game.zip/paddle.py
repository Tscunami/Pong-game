from turtle import Turtle
import random


class Paddle(Turtle):

    def __init__(self, position):
        super().__init__()
        self.shape("square")
        self.penup()
        self.speed(0)
        self.color("hotpink", "MidnightBlue")
        self.shapesize(stretch_wid=5, stretch_len=1)
        self.goto(position)

    def go_up(self):
        if self.ycor() > 200:
            pass
        else:
            new_y = self.ycor() + 80
            self.goto(self.xcor(), new_y)

    def go_down(self):
        if self.ycor() < -200:
            pass
        else:
            new_y = self.ycor() - 80
            self.goto(self.xcor(), new_y)

    def ball_hit(self):
        border_colors = ["hotpink", "GreenYellow", "firebrick2", "orangeRed2"]
        fill_colors = ["MidnightBlue", "BlueViolet", "DarkGoldenrod2", "DarkOrange4"]

        self.color(random.choice(border_colors), random.choice(fill_colors))
