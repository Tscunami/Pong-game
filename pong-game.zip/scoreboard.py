from turtle import Turtle


class Scoreboard(Turtle):

    def __init__(self):
        super().__init__()
        self.color("DarkGreen")
        self.penup()
        self.hideturtle()
        self.l_score = 0s
        self.r_score = 0
        self.goto(-100, 200)
        self.update_scoreboard()

    def update_scoreboard(self):
        self.clear()
        self.goto(-90, 180)
        self.write(self.l_score, align="center", font=("Comic Sans MS", 80, "normal"))
        self.goto(90, 180)
        self.write(self.r_score, align="center", font=("Comic Sans MS", 80, "normal"))

    def l_point(self):
        self.l_score += 1
        self.update_scoreboard()

    def r_point(self):
        self.r_score += 1
        self.update_scoreboard()


class Line(Turtle):

    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.penup()
        self.speed("fastest")
        self.width(8)
        self.goto(0, 300)
        self.pendown()
        self.color("OliveDrab4")
        self.write_line()

    def write_line(self):
        self.setheading(270)

        while self.ycor() > -300:
            self.forward(20)
            self.penup()
            self.forward(20)
            self.pendown()
